from otree.api import (
    models,
    widgets,
    BaseConstants,
    BaseSubsession,
    BaseGroup,
    BasePlayer,
    Currency as c,
    currency_range,
)

author = 'Your name here'

doc = """
Your app description
"""


class Constants(BaseConstants):
    name_in_url = 'Questionnaire'
    players_per_group = None
    num_rounds = 1


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


def make_field(label) -> object:
    return models.IntegerField(
        choices=[
            [1, 'Completely agree'],
            [2, 'Agree'],
            [3, 'Undecided'],
            [4, 'Disagree'],
            [5, 'Completely disagree']
        ],
        label=label,
        widget=widgets.RadioSelectHorizontal,
    )


class Player(BasePlayer):
    Question1 = make_field('1⃣ Having a higher responsibility made me more invested.')
    Question2 = make_field('2⃣ I appreciated having control over the tasks done by others.')
    Question3 = make_field('3⃣ Being aware that I can ensue some kind of punishment for my team made me more careful '
                           'in my work.')
    Question4 = make_field('4⃣ The verification done by the manager occurs to be fair for me.')
    Question5 = make_field('5⃣ Repeating the work did not make it smothering.')
    Question6 = make_field('6⃣ The task was interesting and motivating.')
    Question7 = make_field('7⃣ I am satisfied with the work I provided.')
    Question8 = make_field('8⃣ I feel like the manager deserves a higher salary.')
    Question9 = make_field('9⃣ I would have preferred  to be paid according to my individual work.')
    Question10 = make_field('1⃣0⃣ The earnings reflect the accuracy of work I provided.')
    Question11 = make_field('1⃣1⃣ The earnings were unfairly distributed.')

    def get_back_variables(self):
        self.errors = self.participant.vars['errors']