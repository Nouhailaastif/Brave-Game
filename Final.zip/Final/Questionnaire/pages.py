from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants


class Questionnaire(Page):
    form_model = 'player'
    form_fields = ['Question1',
                   'Question2',
                   'Question3',
                   'Question4',
                   'Question5',
                   'Question6',
                   'Question7',
                   'Question8',
                   'Question9',
                   'Question10',
                   'Question11',
                   ]


class Acknowledgement(Page):
    pass


page_sequence = [
    Questionnaire,
    Acknowledgement
]
